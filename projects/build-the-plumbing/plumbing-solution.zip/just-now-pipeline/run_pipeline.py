"""Run the whole pipeline with one command:  python run_pipeline.py

  1. ingest      new files in landing/ -> raw tables
  2. dbt build   staging and marts models, with every data test straight after its model
  3. freshness   warn if the raw data is getting old
  4. run log     one row in ops.run_log for every run, whether it worked or not

If any data test fails, dbt stops building anything that depends on it, this script records
the failure and exits with an error code. That is what makes a scheduler (GitHub Actions) mark the run red.
"""
import os, sys, time
from datetime import datetime, timezone
from pathlib import Path
import duckdb
from dbt.cli.main import dbtRunner

import ingest

ROOT = Path(__file__).parent.resolve()
DB = ROOT / "warehouse" / "just_now.duckdb"
DBT_ARGS = ["--project-dir", str(ROOT / "transform"), "--profiles-dir", str(ROOT / "transform")]


def log_run(started, status, files, message):
    con = duckdb.connect(str(DB))
    con.execute("CREATE SCHEMA IF NOT EXISTS ops")
    con.execute("""CREATE TABLE IF NOT EXISTS ops.run_log (
        started_at TIMESTAMP, finished_at TIMESTAMP, status VARCHAR, new_files INTEGER, message VARCHAR)""")
    con.execute("INSERT INTO ops.run_log VALUES (?, ?, ?, ?, ?)",
                [started, datetime.now(timezone.utc).replace(tzinfo=None), status, files, message])
    con.close()


def main():
    os.environ["JUST_NOW_DB"] = str(DB)
    os.chdir(ROOT)
    started = datetime.now(timezone.utc).replace(tzinfo=None)
    t = time.time()

    print("===== 1. ingest =====")
    try:
        files = ingest.main()
    except Exception as e:
        log_run(started, "failed", 0, f"ingest: {e}")
        print(f"\nThe pipeline stopped at ingest: {e}")
        sys.exit(1)

    print("\n===== 2. dbt build (models and tests) =====")
    result = dbtRunner().invoke(["build", *DBT_ARGS])
    if not result.success:
        failed = [r.node.name for r in (result.result or []) if str(r.status) in ("fail", "error")]
        log_run(started, "failed", files, "dbt build: " + ", ".join(failed))
        print("\nThe pipeline stopped: these checks failed:", ", ".join(failed) or "see the dbt output above")
        sys.exit(1)

    print("\n===== 3. source freshness =====")
    dbtRunner().invoke(["source", "freshness", *DBT_ARGS])   # warnings only: never stops the run

    log_run(started, "success", files, "ok")
    print(f"\nAll done in {time.time() - t:.0f} seconds. {files} new files loaded.")


if __name__ == "__main__":
    main()
