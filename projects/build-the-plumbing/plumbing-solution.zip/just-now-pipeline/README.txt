Model answers for Build the plumbing. Try each step first.

To run: unzip the three batch zips into this folder (they make landing/), then
    pip install -r requirements.txt
    python run_pipeline.py
