-- Quarantine is for the odd bad row. If more than 1% of order rows are quarantined,
-- something bigger is wrong with the source, and the pipeline should stop.
select count(*) as quarantined
from {{ ref('quarantine_order_versions') }}
having count(*) > 0.01 * (select count(*) from {{ source('raw', 'orders') }})
