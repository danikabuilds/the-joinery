-- An order cannot arrive before it was placed.
select order_id, order_date, delivered_date
from {{ ref('fct_orders') }}
where delivered_date < order_date
