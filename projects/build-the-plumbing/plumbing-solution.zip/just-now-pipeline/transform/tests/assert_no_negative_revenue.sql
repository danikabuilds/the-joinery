-- A singular test: it fails if this query returns any rows.
select order_id, revenue
from {{ ref('fct_orders') }}
where revenue < 0
