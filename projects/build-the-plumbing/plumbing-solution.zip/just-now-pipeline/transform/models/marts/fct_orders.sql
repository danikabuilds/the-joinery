-- The fact table: one row per order, with its latest status and its items added up.
-- Incremental: after the first run, only orders that changed since the last run are rebuilt.
--
-- "Changed" uses _loaded_at (when WE received the data), not updated_at (when it happened).
-- A late file is full of old updated_at values, so filtering on updated_at would skip it forever.
-- An order also counts as changed when its items arrive later than the order itself.
{{ config(materialized='incremental', unique_key='order_id', incremental_strategy='delete+insert') }}
-- depends_on: {{ ref('stg_order_versions') }}
-- (tells dbt about a ref that only appears inside the is_incremental() block below)

with changed as (
    {% if is_incremental() %}
    select order_id from {{ ref('stg_order_versions') }} where _loaded_at > (select max(_loaded_at) from {{ this }})
    union
    select order_id from {{ ref('stg_order_items') }}    where _loaded_at > (select max(_loaded_at) from {{ this }})
    {% else %}
    select order_id from {{ ref('stg_orders') }}
    {% endif %}
),
items as (
    select
        order_id,
        count(*)            as item_count,
        sum(price)          as revenue,
        sum(freight_value)  as freight,
        max(_loaded_at)     as items_loaded_at
    from {{ ref('stg_order_items') }}
    where order_id in (select order_id from changed)
    group by order_id
)
select
    o.order_id,
    o.customer_id,
    cast(o.order_purchase_ts as date)                       as order_date,
    o.order_status,
    o.delivery_method,
    coalesce(i.item_count, 0)                               as item_count,
    i.revenue,
    i.freight,
    i.order_id is null                                      as items_missing,   -- the items file has not arrived yet
    o.promised_date,
    cast(o.delivered_ts as date)                            as delivered_date,
    case when o.delivered_ts is null then null
         else cast(o.delivered_ts as date) > o.promised_date end as is_late,
    date_diff('hour', o.order_purchase_ts, o.delivered_ts) / 24.0 as days_to_deliver,
    o.updated_at,
    greatest(o._loaded_at, coalesce(i.items_loaded_at, o._loaded_at)) as _loaded_at
from {{ ref('stg_orders') }} o
left join items i using (order_id)
where o.order_id in (select order_id from changed)
