select
    cast(d as date)              as date,
    year(d)                      as year,
    month(d)                     as month,
    strftime(d, '%Y-%m')         as year_month,
    dayname(d)                   as day_name,
    isodow(d) in (6, 7)          as is_weekend
from range(date '2025-10-01', date '2026-01-01', interval 1 day) as t(d)
