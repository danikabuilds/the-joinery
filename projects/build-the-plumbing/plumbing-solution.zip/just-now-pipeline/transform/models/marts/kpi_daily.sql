-- The table the morning dashboard reads: one row per day.
select
    f.order_date                                                         as date,
    count(*)                                                             as orders,
    sum(f.revenue) filter (where f.order_status <> 'cancelled')          as revenue,
    count(*) filter (where f.order_status = 'cancelled')                 as cancelled,
    count(*) filter (where f.order_status in ('delivered', 'returned'))  as delivered,
    round(100.0 * avg(case when f.is_late then 1 else 0 end) filter (where f.is_late is not null), 1) as late_pct,
    round(avg(f.days_to_deliver), 2)                                     as avg_days_to_deliver,
    count(*) filter (where f.items_missing)                              as orders_missing_items
from {{ ref('fct_orders') }} f
group by f.order_date
order by f.order_date
