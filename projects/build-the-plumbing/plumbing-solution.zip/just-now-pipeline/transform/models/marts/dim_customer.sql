select customer_id, customer_city, customer_province, signup_date
from {{ ref('stg_customers') }}
