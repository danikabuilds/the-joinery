select
    customer_id,
    customer_city,
    customer_province,
    cast(signup_date as date) as signup_date
from {{ source('raw', 'customers') }}
