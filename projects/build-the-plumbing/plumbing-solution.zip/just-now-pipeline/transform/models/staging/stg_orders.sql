-- One row per order: its LATEST version. A status change arrives as a new row, so the newest one wins.
-- Ties (the same timestamp loaded twice) are broken by load time.
select *
from {{ ref('stg_order_versions') }}
qualify row_number() over (partition by order_id order by updated_at desc, _loaded_at desc) = 1
