-- Rows that failed the rules in stg_order_versions, kept so someone can look at them and fix the source.
select
    *,
    case
        when nullif(trim(customer_id), '') is null then 'missing customer_id'
        else 'unknown status: ' || coalesce(order_status, '(empty)')
    end as reason
from {{ source('raw', 'orders') }}
where nullif(trim(customer_id), '') is null
   or lower(trim(order_status)) not in ('processing', 'shipped', 'delivered', 'cancelled', 'returned')
