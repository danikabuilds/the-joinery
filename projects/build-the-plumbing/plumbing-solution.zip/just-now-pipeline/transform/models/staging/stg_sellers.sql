select seller_id, seller_province
from {{ source('raw', 'sellers') }}
