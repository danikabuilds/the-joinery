select
    order_id,
    cast(order_item_id as integer)          as order_item_id,
    product_id,
    seller_id,
    cast(price as decimal(10, 2))           as price,
    cast(freight_value as decimal(10, 2))   as freight_value,
    _source_file,
    _loaded_at
from {{ source('raw', 'order_items') }}
qualify row_number() over (partition by order_id, order_item_id order by _loaded_at desc) = 1
