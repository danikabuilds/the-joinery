-- Every version of every order, typed and tidied.
-- Exact duplicate rows (the same file content twice) are removed.
-- Rows that break the rules are NOT dropped silently: they go to quarantine_order_versions instead.
with typed as (
    select distinct
        order_id,
        nullif(trim(customer_id), '')                       as customer_id,
        lower(trim(order_status))                           as order_status,
        cast(order_purchase_ts as timestamp)                as order_purchase_ts,
        cast(updated_at as timestamp)                       as updated_at,
        cast(order_estimated_delivery_date as date)         as promised_date,
        cast(nullif(order_delivered_ts, '') as timestamp)   as delivered_ts,
        {{ column_or_null(source('raw', 'orders'), 'delivery_method') }},  -- only in files from 2025-11-15 onwards
        _source_file,
        _loaded_at
    from {{ source('raw', 'orders') }}
)
select *
from typed
where customer_id is not null
  and order_status in ('processing', 'shipped', 'delivered', 'cancelled', 'returned')
