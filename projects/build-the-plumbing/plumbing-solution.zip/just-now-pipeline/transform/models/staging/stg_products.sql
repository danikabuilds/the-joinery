select
    product_id,
    product_category,
    cast(list_price as decimal(10, 2)) as list_price
from {{ source('raw', 'products') }}
