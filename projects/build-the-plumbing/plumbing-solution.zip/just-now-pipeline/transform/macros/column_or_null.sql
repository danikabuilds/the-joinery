-- Schema drift: use a column if the table has it, otherwise an empty (NULL) column with the same name.
-- This lets a model run on data from before AND after a source starts sending a new column.
{% macro column_or_null(relation, column) -%}
  {%- set existing = adapter.get_columns_in_relation(relation) | map(attribute='name') | map('lower') | list -%}
  {%- if column | lower in existing -%}
    {{ column }}
  {%- else -%}
    cast(null as varchar) as {{ column }}
  {%- endif -%}
{%- endmacro %}
