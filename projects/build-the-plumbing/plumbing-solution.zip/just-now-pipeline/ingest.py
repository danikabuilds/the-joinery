"""Ingest: copy new files from landing/ into the raw layer of the warehouse (warehouse/just_now.duckdb).

Run it from the project folder:  python ingest.py

Rules this script follows (each one is a real data engineering habit):
  - Raw means raw. Every column is stored as text, exactly as it arrived. Cleaning happens later, in dbt.
  - Every row is stamped with the file it came from (_source_file) and when it was loaded (_loaded_at).
  - A file is only loaded once. raw.ingested_files remembers what has been loaded, so running this
    twice changes nothing (it is idempotent).
  - If a file brings a column the table has never seen, the column is added instead of crashing.
  - Each file loads in its own transaction: if one fails halfway, nothing from it is kept.
"""
from pathlib import Path
import duckdb

LANDING = Path("landing")
WAREHOUSE = Path("warehouse") / "just_now.duckdb"
DAILY_TABLES = ["orders", "order_items"]           # landing/orders/*.csv -> raw.orders, and so on
REFERENCE = ["customers", "sellers", "products"]   # landing/reference/*.csv, replaced in full each run


def connect():
    WAREHOUSE.parent.mkdir(exist_ok=True)
    con = duckdb.connect(str(WAREHOUSE))
    con.execute("CREATE SCHEMA IF NOT EXISTS raw")
    con.execute("""CREATE TABLE IF NOT EXISTS raw.ingested_files (
        file_name VARCHAR PRIMARY KEY, table_name VARCHAR, row_count INTEGER, loaded_at TIMESTAMP)""")
    return con


def read_file(con, path):
    """Read one CSV with every column as text, plus the two stamp columns."""
    return f"""SELECT *, '{path.name}' AS _source_file, current_timestamp AS _loaded_at
               FROM read_csv('{path.as_posix()}', all_varchar = true, header = true)"""


def table_exists(con, table):
    return con.execute("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'raw' AND table_name = ?", [table]).fetchone()[0] > 0


def add_new_columns(con, table, path):
    """Schema drift: if the file has columns the table does not, add them (as text)."""
    file_cols = [r[0] for r in con.execute(f"DESCRIBE {read_file(con, path)}").fetchall()]
    table_cols = {r[0] for r in con.execute(f"DESCRIBE raw.{table}").fetchall()}
    for col in file_cols:
        if col not in table_cols:
            con.execute(f'ALTER TABLE raw.{table} ADD COLUMN "{col}" VARCHAR')
            print(f"  new column found in {path.name}: {col} (added to raw.{table})")


def load_daily(con, table):
    done = {r[0] for r in con.execute("SELECT file_name FROM raw.ingested_files WHERE table_name = ?", [table]).fetchall()}
    files = sorted((LANDING / table).glob(f"{table}_*.csv"))
    new = [f for f in files if f.name not in done]
    for path in new:
        con.execute("BEGIN TRANSACTION")
        try:
            if not table_exists(con, table):
                con.execute(f"CREATE TABLE raw.{table} AS {read_file(con, path)} LIMIT 0")
            add_new_columns(con, table, path)
            before = con.execute(f"SELECT COUNT(*) FROM raw.{table}").fetchone()[0]
            con.execute(f"INSERT INTO raw.{table} BY NAME {read_file(con, path)}")   # BY NAME: match columns by name, not position
            rows = con.execute(f"SELECT COUNT(*) FROM raw.{table}").fetchone()[0] - before
            con.execute("INSERT INTO raw.ingested_files VALUES (?, ?, ?, current_timestamp)", [path.name, table, rows])
            con.execute("COMMIT")
        except Exception:
            con.execute("ROLLBACK")
            raise
    print(f"raw.{table:12s} {len(new):3d} new files, {len(files) - len(new):3d} already loaded")
    return len(new)


def load_reference(con):
    for name in REFERENCE:
        path = LANDING / "reference" / f"{name}.csv"
        if path.exists():
            con.execute(f"CREATE OR REPLACE TABLE raw.{name} AS {read_file(con, path)}")
            n = con.execute(f"SELECT COUNT(*) FROM raw.{name}").fetchone()[0]
            print(f"raw.{name:12s} {n:,} rows (full snapshot)")


def main():
    con = connect()
    try:
        load_reference(con)
        new_files = sum(load_daily(con, t) for t in DAILY_TABLES)
    finally:
        con.close()
    return new_files


if __name__ == "__main__":
    main()
