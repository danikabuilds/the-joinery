# Data contract: daily orders feed

**Owner:** Orders system team. **Consumer:** Data team (this pipeline).
**Arrives:** one pair of files per day in `landing/orders/` and `landing/order_items/`, by 05:00, for the previous day. Files can arrive late; a late file must still be loaded.

## orders_YYYY-MM-DD.csv: one row per order per status change
| column | type | rules |
|---|---|---|
| order_id | text | required; the same order appears once per status change |
| customer_id | text | required; must exist in `reference/customers.csv` |
| order_status | text | one of processing, shipped, delivered, cancelled, returned |
| order_purchase_ts | timestamp | required; the same on every version of an order |
| updated_at | timestamp | required; when this status change happened. The latest one wins |
| order_estimated_delivery_date | date | required |
| order_delivered_ts | timestamp | empty until the order is delivered |
| delivery_method | text | added from 2025-11-15: standard, express or collect. Empty before that |

## order_items_YYYY-MM-DD.csv: one row per item, sent once, on the day the order is placed
| column | type | rules |
|---|---|---|
| order_id | text | required; matches an order |
| order_item_id | integer | 1, 2, 3 … within an order; (order_id, order_item_id) is unique |
| product_id | text | must exist in `reference/products.csv` |
| seller_id | text | required |
| price | decimal | rand, 0 or more |
| freight_value | decimal | rand, 0 or more |

## What happens when the rules are broken
- A row that breaks a rule is moved to quarantine with a reason, and the rest of the file still loads.
- If more than 1% of rows are quarantined, the pipeline stops and nobody gets that morning's numbers until someone checks.
- New columns are added to the raw layer automatically, and the data team is told (the ingest log says so).
