-- Step 6: model the data for analysis.
-- One fact table with ONE ROW PER ORDER (that is its grain), plus dimension tables to slice it by.

-- Customers: who bought, and where they live
CREATE OR REPLACE TABLE dim_customer AS
SELECT customer_id, customer_city, customer_province, signup_date
FROM customers;

-- Products: what was sold
CREATE OR REPLACE TABLE dim_product AS
SELECT product_id, product_name, product_category, product_weight_g
FROM products;

-- Dates: one row per day, so every chart can use the same calendar
CREATE OR REPLACE TABLE dim_date AS
SELECT
  d::DATE                          AS date,
  year(d)                          AS year,
  month(d)                         AS month,
  strftime(d, '%Y-%m')             AS year_month,
  strftime(d, '%B')                AS month_name,
  dayname(d)                       AS day_name,
  isodow(d) IN (6, 7)              AS is_weekend
FROM range(DATE '2024-01-01', DATE '2026-01-01', INTERVAL 1 DAY) AS t(d);

-- The fact table: one row per order, with the numbers the business asks about
CREATE OR REPLACE TABLE fact_orders AS
WITH items AS (
  SELECT
    order_id,
    COUNT(*)                     AS item_count,
    SUM(price)                   AS revenue,        -- items with a missing price are left out (SUM skips NULL)
    SUM(freight_value)           AS freight,
    MIN(seller_id)               AS seller_id,      -- every order in this store ships from one seller
    BOOL_OR(price_missing)       AS has_missing_price
  FROM order_items
  GROUP BY order_id
),
latest_review AS (
  SELECT order_id, review_score FROM reviews
)
SELECT
  o.order_id,
  o.customer_id,
  i.seller_id,
  CAST(o.order_purchase_ts AS DATE)                         AS order_date,
  o.order_status,
  i.item_count,
  i.revenue,
  i.freight,
  i.has_missing_price,
  o.order_estimated_delivery_date                           AS promised_date,
  CAST(o.order_delivered_ts AS DATE)                        AS delivered_date,
  date_diff('day', o.order_estimated_delivery_date, CAST(o.order_delivered_ts AS DATE)) AS days_late,
  CASE WHEN o.order_delivered_ts IS NULL THEN NULL
       ELSE CAST(o.order_delivered_ts AS DATE) > o.order_estimated_delivery_date END AS is_late,
  CASE
    WHEN o.order_delivered_ts IS NULL THEN NULL
    WHEN CAST(o.order_delivered_ts AS DATE) <= o.order_estimated_delivery_date THEN '1. On time or early'
    WHEN date_diff('day', o.order_estimated_delivery_date, CAST(o.order_delivered_ts AS DATE)) <= 3 THEN '2. 1 to 3 days late'
    ELSE '3. 4 or more days late'
  END                                                       AS delivery_timing,
  date_diff('hour', o.order_purchase_ts, o.order_delivered_ts) / 24.0 AS days_to_deliver,
  r.review_score
FROM orders o
JOIN items i USING (order_id)
LEFT JOIN latest_review r USING (order_id);
