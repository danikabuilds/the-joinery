"""Step 8 (Python route): draw the four dashboard charts as PNG images in output/.

Run it from the project folder after analyse.py:  python charts.py
"""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")                     # draw to files, no window needed
import matplotlib.pyplot as plt

OUT = Path("output")
BLUE, GREY, RED = "#2A6FDB", "#9AA5B1", "#D64545"


def style(ax, title, subtitle):
    ax.set_title(title, loc="left", fontsize=13, fontweight="bold", pad=22)
    ax.text(0, 1.02, subtitle, transform=ax.transAxes, fontsize=9.5, color="#555")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", alpha=.25)


def revenue_trend():
    df = pd.read_csv(OUT / "q1_monthly_revenue.csv")
    fig, ax = plt.subplots(figsize=(10, 4.2))
    ax.plot(df["month"], df["revenue"] / 1e6, color=BLUE, linewidth=2, marker="o", markersize=4)
    style(ax, "Revenue is growing, with a Black Friday spike every November", "Monthly revenue, R millions")
    ax.set_xticks(range(0, len(df), 2), df["month"][::2], rotation=45, ha="right", fontsize=8)
    fig.tight_layout(); fig.savefig(OUT / "chart_revenue_trend.png", dpi=150); plt.close(fig)


def late_by_province():
    df = pd.read_csv(OUT / "q3_late_by_province.csv").sort_values("late_pct")
    fig, ax = plt.subplots(figsize=(8, 4.6))
    colours = [RED if v >= 20 else GREY for v in df["late_pct"]]
    ax.barh(df["province"], df["late_pct"], color=colours)
    for y, v in enumerate(df["late_pct"]):
        ax.text(v + .5, y, f"{v:.0f}%", va="center", fontsize=9)
    style(ax, "Far from the sellers, more than 1 in 4 orders arrive late", "Delivered orders that arrived after the promised date, %")
    ax.grid(axis="x", alpha=.25); ax.grid(axis="y", visible=False)
    fig.tight_layout(); fig.savefig(OUT / "chart_late_by_province.png", dpi=150); plt.close(fig)


def reviews_vs_lateness():
    df = pd.read_csv(OUT / "q4_reviews_vs_lateness.csv")
    labels = [d.split(". ", 1)[1] for d in df["delivery"]]
    fig, ax = plt.subplots(figsize=(7, 4.2))
    bars = ax.bar(labels, df["avg_score"], color=[BLUE, GREY, RED])
    for b, v in zip(bars, df["avg_score"]):
        ax.text(b.get_x() + b.get_width() / 2, v + .05, f"{v:.1f}", ha="center", fontsize=10)
    ax.set_ylim(0, 5)
    style(ax, "Late orders lose more than two review stars", "Average review score (1 to 5) by delivery timing")
    fig.tight_layout(); fig.savefig(OUT / "chart_reviews_vs_lateness.png", dpi=150); plt.close(fig)


def top_categories():
    df = pd.read_csv(OUT / "q2_top_categories.csv").sort_values("revenue")
    fig, ax = plt.subplots(figsize=(8, 4.6))
    ax.barh(df["category"].str.replace("_", " "), df["revenue"] / 1e6, color=GREY)
    ax.barh(df["category"].str.replace("_", " ").iloc[-1:], df["revenue"].iloc[-1:] / 1e6, color=BLUE)
    style(ax, "Electronics outsells the next two categories combined", "Revenue in 2025 by category, R millions")
    ax.grid(axis="x", alpha=.25); ax.grid(axis="y", visible=False)
    fig.tight_layout(); fig.savefig(OUT / "chart_top_categories.png", dpi=150); plt.close(fig)


def main():
    revenue_trend(); late_by_province(); reviews_vs_lateness(); top_categories()
    print("Charts saved in", OUT.resolve())


if __name__ == "__main__":
    main()
