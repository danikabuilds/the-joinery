"""Step 9: run the whole pipeline with one command.

Run it from the project folder:  python run_all.py
clean -> load -> model -> analyse -> charts. If any step fails, it stops and says which one.
This is the same idea as the pipelines data engineers schedule to run every night.
"""
import time
import clean, load, model, analyse, charts

STEPS = [("clean", clean.main), ("load", load.main), ("model", model.main),
         ("analyse", analyse.main), ("charts", charts.main)]


def main():
    started = time.time()
    for name, step in STEPS:
        print(f"\n===== {name} =====")
        t = time.time()
        try:
            step()
        except Exception as e:
            print(f"\nThe pipeline stopped at the '{name}' step: {e}")
            raise SystemExit(1)
        print(f"({name} took {time.time() - t:.1f} s)")
    print(f"\nAll done in {time.time() - started:.1f} seconds.")


if __name__ == "__main__":
    main()
