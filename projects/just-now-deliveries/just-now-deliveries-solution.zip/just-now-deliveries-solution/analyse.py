"""Step 7: run every business question in questions.sql, print the answers and save each one as a CSV in output/.

Run it from the project folder:  python analyse.py
"""
from pathlib import Path
import duckdb

DB = "just_now.duckdb"
OUT = Path("output")


def read_questions(path="questions.sql"):
    """Split questions.sql into {name: sql} using the '-- name:' lines."""
    queries, name, lines = {}, None, []
    for line in open(path, encoding="utf-8"):
        if line.startswith("-- name:"):
            if name:
                queries[name] = "".join(lines)
            name, lines = line.split(":", 1)[1].strip(), []
        elif name:
            lines.append(line)
    if name:
        queries[name] = "".join(lines)
    return queries


def main():
    OUT.mkdir(exist_ok=True)
    con = duckdb.connect(DB, read_only=True)
    for name, sql in read_questions().items():
        df = con.execute(sql).df()
        df.to_csv(OUT / f"{name}.csv", index=False)
        print(f"\n--- {name} ---")
        print(df.to_string(index=False))
    con.close()


if __name__ == "__main__":
    main()
