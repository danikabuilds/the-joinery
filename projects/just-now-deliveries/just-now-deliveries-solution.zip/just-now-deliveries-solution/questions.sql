-- Step 7: the business questions. Each one starts with "-- name: ..." so analyse.py can run them one by one.
-- Revenue means the price of items on orders that were not cancelled (freight is the courier's money, not ours).

-- name: q1_monthly_revenue
-- Q1. Are we growing? Revenue and orders per month.
SELECT
  strftime(order_date, '%Y-%m')         AS month,
  COUNT(*)                              AS orders,
  ROUND(SUM(revenue), 0)                AS revenue
FROM fact_orders
WHERE order_status <> 'cancelled'
GROUP BY month
ORDER BY month;

-- name: q1b_yearly_growth
-- Q1 (part two). Growth from 2024 to 2025.
WITH y AS (
  SELECT year(order_date) AS yr, SUM(revenue) AS revenue, COUNT(*) AS orders
  FROM fact_orders
  WHERE order_status <> 'cancelled'
  GROUP BY yr
)
SELECT
  yr,
  ROUND(revenue, 0)                                                      AS revenue,
  orders,
  ROUND(revenue / orders, 2)                                             AS avg_order_value,
  ROUND(100.0 * (revenue / LAG(revenue) OVER (ORDER BY yr) - 1), 1)      AS revenue_growth_pct
FROM y
ORDER BY yr;

-- name: q2_top_categories
-- Q2. What sells? Revenue by category in 2025, with each category's share.
SELECT
  p.product_category                                         AS category,
  ROUND(SUM(i.price), 0)                                     AS revenue,
  ROUND(100.0 * SUM(i.price) / SUM(SUM(i.price)) OVER (), 1) AS share_pct
FROM order_items i
JOIN orders o     USING (order_id)
JOIN dim_product p USING (product_id)
WHERE o.order_status <> 'cancelled'
  AND year(o.order_purchase_ts) = 2025
GROUP BY category
ORDER BY revenue DESC;

-- name: q3_late_by_province
-- Q3. Where are deliveries failing? Share of delivered orders that arrived after the promised date.
SELECT
  c.customer_province                       AS province,
  COUNT(*)                                  AS delivered_orders,
  ROUND(100.0 * AVG(f.is_late::INT), 1)     AS late_pct,
  ROUND(AVG(f.days_to_deliver), 1)          AS avg_days_to_deliver
FROM fact_orders f
JOIN dim_customer c USING (customer_id)
WHERE f.order_status = 'delivered'
  AND f.is_late IS NOT NULL                 -- leaves out the 180 orders with no delivery date
GROUP BY province
ORDER BY late_pct DESC;

-- name: q4_reviews_vs_lateness
-- Q4. Does slow delivery hurt our reviews? Average score by how late the order was.
SELECT
  delivery_timing                       AS delivery,   -- a column we built in the model, so the rule lives in one place
  COUNT(*)                              AS reviews,
  ROUND(AVG(review_score), 2)           AS avg_score,
  ROUND(100.0 * AVG((review_score <= 2)::INT), 1) AS pct_1_or_2_stars
FROM fact_orders
WHERE order_status = 'delivered'
  AND review_score IS NOT NULL
  AND delivery_timing IS NOT NULL
GROUP BY delivery
ORDER BY delivery;

-- name: q5_repeat_customers
-- Q5. Do customers come back? Share of customers with two or more orders, and their share of revenue.
WITH per_customer AS (
  SELECT customer_id, COUNT(*) AS orders, SUM(revenue) AS revenue
  FROM fact_orders
  WHERE order_status <> 'cancelled'
  GROUP BY customer_id
)
SELECT
  COUNT(*)                                                         AS customers,
  SUM((orders >= 2)::INT)                                          AS repeat_customers,
  ROUND(100.0 * AVG((orders >= 2)::INT), 1)                        AS repeat_pct,
  ROUND(100.0 * SUM(CASE WHEN orders >= 2 THEN revenue END) / SUM(revenue), 1) AS repeat_revenue_pct
FROM per_customer;

-- name: q6_worst_month
-- Q6. Detective question: which month and province had the worst late rate? (Only cells with 100+ deliveries.)
SELECT
  strftime(f.order_date, '%Y-%m')           AS month,
  c.customer_province                       AS province,
  COUNT(*)                                  AS delivered_orders,
  ROUND(100.0 * AVG(f.is_late::INT), 1)     AS late_pct
FROM fact_orders f
JOIN dim_customer c USING (customer_id)
WHERE f.order_status = 'delivered' AND f.is_late IS NOT NULL
GROUP BY month, province
HAVING COUNT(*) >= 100
ORDER BY late_pct DESC
LIMIT 5;

-- name: q7_payment_mix
-- Q7. How do customers pay? Share of payments and average amount by payment type.
SELECT
  payment_type,
  COUNT(*)                                          AS payments,
  ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS share_pct,
  ROUND(AVG(payment_value), 2)                      AS avg_amount,
  ROUND(AVG(payment_installments), 2)               AS avg_instalments
FROM payments
GROUP BY payment_type
ORDER BY payments DESC;
