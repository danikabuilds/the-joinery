"""Step 3: a first look at every file.

Run it from the project folder:  python profile_data.py
It prints, for each CSV: how many rows and columns, each column's type,
how many values are missing, and how many rows are exact duplicates.
"""
from pathlib import Path
import pandas as pd

DATA = Path("data")


def profile(path):
    df = pd.read_csv(path, dtype=str)          # read everything as text first: nothing gets changed behind your back
    print(f"\n=== {path.name}: {len(df):,} rows, {df.shape[1]} columns ===")
    print(f"Exact duplicate rows: {df.duplicated().sum():,}")
    summary = pd.DataFrame({
        "missing": df.isna().sum(),
        "missing_%": (df.isna().mean() * 100).round(1),
        "distinct": df.nunique(),
        "example": df.iloc[0],
    })
    print(summary.to_string())


def main():
    for path in sorted(DATA.glob("*.csv")):
        profile(path)


if __name__ == "__main__":
    main()
