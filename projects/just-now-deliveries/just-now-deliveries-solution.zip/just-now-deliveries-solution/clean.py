"""Step 4: clean the raw files and save tidy copies in the clean/ folder.

Run it from the project folder:  python clean.py
Each function fixes one table and records what it changed, so you can explain every fix.
The raw files in data/ are never changed.
"""
from pathlib import Path
import pandas as pd

DATA, CLEAN = Path("data"), Path("clean")
report = []  # one line per fix, printed at the end and saved to clean/cleaning_report.txt


def log(table, message, count):
    report.append(f"{table:12s} {message}: {count:,}")


def read(name):
    # Read as text so pandas never guesses a type wrongly (for example, IDs that look like numbers).
    return pd.read_csv(DATA / f"{name}.csv", dtype=str, keep_default_na=False, na_values=[""])


def tidy_text(s):
    """Remove spaces at the start and end, and squeeze double spaces inside."""
    return s.str.strip().str.replace(r"\s+", " ", regex=True)


# ---------- places: one spelling for each city and province ----------
CITY_FIX = {
    "joburg": "Johannesburg", "jhb": "Johannesburg", "jozi": "Johannesburg",
    "cpt": "Cape Town", "kaapstad": "Cape Town",
    "dbn": "Durban", "ethekwini": "Durban",
    "pta": "Pretoria", "tshwane": "Pretoria",
    "port elizabeth": "Gqeberha", "pe": "Gqeberha",
    "bloem": "Bloemfontein", "nelspruit": "Mbombela",
}
PROVINCE_FIX = {
    "gp": "Gauteng", "gau": "Gauteng",
    "wc": "Western Cape", "w cape": "Western Cape",
    "kzn": "KwaZulu-Natal", "kwazulu natal": "KwaZulu-Natal",
    "ec": "Eastern Cape", "e cape": "Eastern Cape",
    "mp": "Mpumalanga",
    "fs": "Free State", "freestate": "Free State",
    "lp": "Limpopo", "lim": "Limpopo",
    "nw": "North West", "north-west": "North West",
    "nc": "Northern Cape", "n cape": "Northern Cape",
}
PROVINCES = ["Gauteng", "Western Cape", "KwaZulu-Natal", "Eastern Cape", "Mpumalanga",
             "Free State", "Limpopo", "North West", "Northern Cape"]


def fix_city(s):
    s = tidy_text(s)
    key = s.str.lower()
    # known nicknames first, then proper capitalisation for the rest ("cape town" -> "Cape Town")
    return key.map(CITY_FIX).fillna(s.str.title())


def fix_province(s):
    s = tidy_text(s)
    key = s.str.lower()
    official = {p.lower(): p for p in PROVINCES}
    return key.map(PROVINCE_FIX).fillna(key.map(official))


def clean_places(df, prefix, table):
    city, prov = f"{prefix}_city", f"{prefix}_province"
    before_city, before_prov = df[city].nunique(), df[prov].nunique()
    df[city] = fix_city(df[city])
    df[prov] = fix_province(df[prov])
    log(table, f"city spellings {before_city} -> {df[city].nunique()}, provinces {before_prov} -> {df[prov].nunique()}", len(df))
    unknown = df[prov].isna().sum()
    if unknown:
        log(table, "WARNING province not recognised", unknown)
    return df


# ---------- dates: two formats in the same column ----------
def parse_dates(s):
    """Most dates look like 2024-03-07 09:05:32. Some look like 07/03/2024 09:05 (day first).
    Try the main format, then the second format for whatever is left."""
    first = pd.to_datetime(s, format="%Y-%m-%d %H:%M:%S", errors="coerce")
    second = pd.to_datetime(s, format="%d/%m/%Y %H:%M", errors="coerce")
    return first.fillna(second)


# ---------- one function per table ----------
def clean_customers():
    df = read("customers")
    df = clean_places(df, "customer", "customers")
    df["signup_date"] = pd.to_datetime(df["signup_date"])
    return df


def clean_sellers():
    return clean_places(read("sellers"), "seller", "sellers")


def clean_products():
    df = read("products")
    before = df["product_category"].nunique()
    df["product_category"] = tidy_text(df["product_category"]).str.lower()
    missing = df["product_category"].isna().sum()
    df["product_category"] = df["product_category"].fillna("unknown")
    log("products", f"category spellings {before} -> {df['product_category'].nunique()}, missing set to 'unknown'", missing)
    df["product_weight_g"] = pd.to_numeric(df["product_weight_g"])
    zero = (df["product_weight_g"] == 0).sum()
    df.loc[df["product_weight_g"] == 0, "product_weight_g"] = pd.NA  # a weight of 0 g is not real: treat it as unknown
    log("products", "zero weights set to missing", zero)
    return df


def clean_orders():
    df = read("orders")
    n = len(df)
    df = df.drop_duplicates()
    log("orders", "exact duplicate rows removed", n - len(df))

    test = df["order_id"].str.startswith("TEST")
    log("orders", "test orders removed", test.sum())
    df = df[~test].copy()

    before = df["order_status"].nunique()
    df["order_status"] = tidy_text(df["order_status"]).str.lower()
    log("orders", f"status spellings {before} -> {df['order_status'].nunique()}", len(df))

    for col in ["order_purchase_ts", "order_dispatched_ts", "order_delivered_ts"]:
        other = df[col].str.contains("/", na=False).sum()
        df[col] = parse_dates(df[col])
        log("orders", f"{col}: dates in day/month/year format converted", other)
    df["order_estimated_delivery_date"] = pd.to_datetime(df["order_estimated_delivery_date"])

    # Delivered orders with no delivery date: keep them (the sale happened), but flag them,
    # so delivery-time questions can leave them out.
    df["delivery_date_missing"] = (df["order_status"] == "delivered") & df["order_delivered_ts"].isna()
    log("orders", "delivered orders with no delivery date (flagged, kept)", df["delivery_date_missing"].sum())
    return df


def clean_items(valid_orders):
    df = read("order_items")
    for col in ["price", "freight_value"]:
        df[col] = pd.to_numeric(df[col])
    df["order_item_id"] = pd.to_numeric(df["order_item_id"])

    orphans = ~df["order_id"].isin(valid_orders)
    log("order_items", "items of removed (test) orders dropped", orphans.sum())
    df = df[~orphans].copy()

    # A price of 0 is a recording error, not a free gift. Flag it and leave it out of revenue.
    df["price_missing"] = df["price"] == 0
    df.loc[df["price_missing"], "price"] = pd.NA
    log("order_items", "zero prices set to missing (flagged)", df["price_missing"].sum())

    # Freight of R9,999 on a small parcel is a placeholder, not a real charge.
    outlier = df["freight_value"] >= 5000
    df.loc[outlier, "freight_value"] = pd.NA
    log("order_items", "freight values of R5,000 or more set to missing", outlier.sum())
    return df


def clean_payments(valid_orders):
    df = read("payments")
    df["payment_value"] = pd.to_numeric(df["payment_value"])
    df["payment_installments"] = pd.to_numeric(df["payment_installments"])
    df["payment_sequential"] = pd.to_numeric(df["payment_sequential"])
    before = df["payment_type"].nunique()
    key = tidy_text(df["payment_type"]).str.lower().str.replace("-", "_").str.replace(" ", "_")
    df["payment_type"] = key.replace({"credit_card": "card", "bank_transfer": "eft", "gift_voucher": "voucher"})
    log("payments", f"payment type spellings {before} -> {df['payment_type'].nunique()}", len(df))
    df = df[df["order_id"].isin(valid_orders)]
    return df


def clean_reviews(valid_orders):
    df = read("reviews")
    df["review_score"] = pd.to_numeric(df["review_score"])
    df["review_date"] = pd.to_datetime(df["review_date"])

    bad = ~df["review_score"].between(1, 5)
    log("reviews", "scores outside 1 to 5 removed", bad.sum())
    df = df[~bad]

    # Some orders were reviewed twice. Keep the latest review for each order.
    n = len(df)
    df = df.sort_values("review_date").drop_duplicates("order_id", keep="last")
    log("reviews", "older duplicate reviews removed (latest kept)", n - len(df))
    return df[df["order_id"].isin(valid_orders)]


def main():
    CLEAN.mkdir(exist_ok=True)
    report.clear()
    orders = clean_orders()
    valid = set(orders["order_id"])
    tables = {
        "customers": clean_customers(),
        "sellers": clean_sellers(),
        "products": clean_products(),
        "orders": orders,
        "order_items": clean_items(valid),
        "payments": clean_payments(valid),
        "reviews": clean_reviews(valid),
    }
    for name, df in tables.items():
        df.to_csv(CLEAN / f"{name}.csv", index=False)
    text = "\n".join(report)
    (CLEAN / "cleaning_report.txt").write_text(text + "\n")
    print(text)
    print(f"\nClean files saved in {CLEAN.resolve()}")


if __name__ == "__main__":
    main()
