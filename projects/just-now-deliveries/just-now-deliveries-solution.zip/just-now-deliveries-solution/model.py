"""Step 6: build the analysis model (model.sql) inside just_now.duckdb.

Run it from the project folder:  python model.py
"""
from pathlib import Path
import duckdb

DB = "just_now.duckdb"


def main():
    con = duckdb.connect(DB)
    con.execute(open("model.sql", encoding="utf-8").read())
    for t in ["dim_customer", "dim_product", "dim_date", "fact_orders"]:
        n = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        print(f"built {t:13s} {n:>7,} rows")
    # a quick check that the grain is right: exactly one row per order
    dupes = con.execute("SELECT COUNT(*) - COUNT(DISTINCT order_id) FROM fact_orders").fetchone()[0]
    print("one row per order:", "yes" if dupes == 0 else f"NO, {dupes} extra rows")
    # copies of the model as CSV files, for Power BI or Excel (Get data > Text/CSV)
    Path("model_export").mkdir(exist_ok=True)
    for t in ["dim_customer", "dim_product", "dim_date", "fact_orders"]:
        con.execute(f"COPY {t} TO 'model_export/{t}.csv' (HEADER)")
    print("model tables saved as CSV in model_export/ (for Power BI)")
    con.close()


if __name__ == "__main__":
    main()
