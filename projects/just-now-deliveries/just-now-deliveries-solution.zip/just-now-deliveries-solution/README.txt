Just Now Deliveries: model answers
==================================

Try each step yourself first. Then compare with these.

Copy these files into your just-now-deliveries folder, next to the data folder, then run:
    pip install -r requirements.txt
    python run_all.py

profile_data.py  Step 3: first look at every file
clean.py         Step 4: clean the raw files into clean/
load.py          Step 5: load the clean files into just_now.duckdb
model.sql        Step 6: the star schema (fact_orders and the dimensions)
model.py         Step 6: builds model.sql and exports it for Power BI
questions.sql    Step 7: the business questions
analyse.py       Step 7: runs questions.sql and saves answers to output/
charts.py        Step 8: the dashboard charts as images
run_all.py       Step 9: the whole pipeline in one command
