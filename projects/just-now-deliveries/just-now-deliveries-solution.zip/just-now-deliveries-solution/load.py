"""Step 5: load the clean files into a DuckDB database file called just_now.duckdb.

Run it from the project folder:  python load.py
DuckDB is a database that lives in one file on your computer. There is no server to set up.
"""
from pathlib import Path
import duckdb

CLEAN = Path("clean")
DB = "just_now.duckdb"
TABLES = ["customers", "sellers", "products", "orders", "order_items", "payments", "reviews"]


def main():
    con = duckdb.connect(DB)
    for t in TABLES:
        # read_csv_auto looks at the file and picks sensible column types (dates, numbers, text)
        con.execute(f"CREATE OR REPLACE TABLE {t} AS SELECT * FROM read_csv_auto('{(CLEAN / (t + '.csv')).as_posix()}')")
        n = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        print(f"loaded {t:12s} {n:>7,} rows")
    con.close()


if __name__ == "__main__":
    main()
