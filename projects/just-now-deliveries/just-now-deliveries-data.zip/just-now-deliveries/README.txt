Just Now Deliveries: project data
=================================

1. Unzip this file. You get a folder called just-now-deliveries with a data folder inside.
2. Open the just-now-deliveries folder in VS Code (File > Open Folder).
3. Follow the steps on The Joinery: https://danikabuilds.github.io/the-joinery/#/projects/just-now-deliveries

DATA_DICTIONARY.md explains every column. The data is made up, so you can use it freely.
