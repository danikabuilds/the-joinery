# Just Now Deliveries: data dictionary

Just Now Deliveries is a fictional South African online store. Every row in these files was made up
by a computer program, so you can use, share and change the data freely. Prices are in rand (R).
The data covers 1 January 2024 to 31 December 2025.

The files are raw: they contain mistakes on purpose, like real exports do. Cleaning them is part of the project.

## customers.csv: one row per customer
| column | meaning |
|---|---|
| customer_id | Unique ID, for example C00042 |
| customer_city | City the customer lives in |
| customer_province | Province the customer lives in |
| signup_date | Date the customer created an account |

## sellers.csv: one row per seller (the shops that sell through Just Now)
| column | meaning |
|---|---|
| seller_id | Unique ID, for example S007 |
| seller_city | City the seller ships from |
| seller_province | Province the seller ships from |

## products.csv: one row per product
| column | meaning |
|---|---|
| product_id | Unique ID, for example P0123 |
| product_name | Short product name |
| product_category | Category, for example electronics |
| product_weight_g | Weight in grams |

## orders.csv: one row per order
| column | meaning |
|---|---|
| order_id | Unique ID, for example O000123 |
| customer_id | Who placed the order (links to customers) |
| order_purchase_ts | Date and time the order was placed |
| order_status | delivered, shipped (still on the way), cancelled or returned |
| order_dispatched_ts | Date and time the seller handed it to the courier |
| order_delivered_ts | Date and time it reached the customer |
| order_estimated_delivery_date | The delivery date the customer was promised |

## order_items.csv: one row per item in an order
| column | meaning |
|---|---|
| order_id | The order (links to orders) |
| order_item_id | 1 for the first item in the order, 2 for the second, and so on |
| product_id | What was bought (links to products) |
| seller_id | Who sold it (links to sellers) |
| price | Price paid for the item, in rand |
| freight_value | Delivery charge for the item, in rand |

## payments.csv: one row per payment (an order can be paid in two parts)
| column | meaning |
|---|---|
| order_id | The order (links to orders) |
| payment_sequential | 1 for the first payment on the order, 2 for the second |
| payment_type | card, instant_eft, eft or voucher |
| payment_installments | Number of monthly instalments (card only) |
| payment_value | Amount paid, in rand |

## reviews.csv: one row per review
| column | meaning |
|---|---|
| review_id | Unique ID |
| order_id | The order being reviewed (links to orders) |
| review_score | 1 (worst) to 5 (best) |
| review_comment | Optional short comment |
| review_date | Date the review was written |
